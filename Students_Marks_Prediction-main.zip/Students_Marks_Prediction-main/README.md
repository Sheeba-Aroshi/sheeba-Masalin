# Students_Marks_Prediction

ABSTRACT

Education is very important issue regarding development of a country. The main objective of education institutions is to provide high quality education to its students. One way to accomplish this is by predicting student’s academic performance and thereby taking early steps to improve student’s performance and teaching quality.

Analyzing and prediction of academic performance is important for any education institutions. Predicting student performance can help teachers to take stages. With the advancement of machine learning supervised and unsupervised techniques developing these kinds of applications are helping teachers to analyze students in better way compare to existing methods. In this student marks prediction using linear regression project student academic performance is prediction considering input as number of hourly rate and predict your academic percentage marks and accuracy of the modal is calculated.

This system aims to predict student’s marks using linear regression. The idea behind this analysis is to predict the marks of students by their studying hours.  
 
What is already accomplished



List of features


•	Mobile Experience easy UI experience for users.

•	It’s a Machine learning based data mining techniques are used to automate process of student performance prediction using linear regression technique.


•	Done work on marks prediction systems which number of hour’s are used for giving marks for students and evaluation of each student is done.

•	Association rule mining and supervised algorithms are used for classifying students based on their marks.


•	These methods work on data mining techniques which are based on after completing data.

•	Data set is pre-processed and features and labels are extracted from dataset is split in to test and train sets then linear regression is applied to dataset for prediction.


•	Before final marks are evaluated prediction can be performed.












•	Using machine learning process automation of marks prediction can be done.

•	Data analysis and prediction is performed on textual data.


•	 Data analysis is performed for various factors. 

•	 The latest machine learning models are used for training models that are accurate.

•	These kinds of applications are helping to analyze marks in better way.

 



TECHNOLOGY USED



Frontend:
1.	HTML:- HyperText Markup Language is the standard markup language for documents designed to be displayed in a web browser. It can be assisted by technologies such as CSS and scripting languages.
2.	CSS:- Cascading Style Sheets is a style sheet language used for describing the presentation of a document written is a markup language such as HTML. CSS try to beautify markup languages code.
3.	Bootstrap:- Bootstrap is a free and open-source CSS framework directed are responsive, mobile-first front-end web development. It contains HTML, CSS and JavaScript based design templates for typography, forms, buttons, navigation and other interface components.





Backend:
1.	Python:- Python is a high-level, general purpose programming language. Its design philosophy emphasizes code readability with the use of significant indentation. Its language constructs and object-oriented approach aim to help programmers write clear, logical code for small and large-scale project.
2.	Flask:- Flask is a micro web framework written in python. It is classified as a microframework because it does not require particular tools or libraries. It has no database abstraction layer, form validation, or any other components where pre-existing third-party libraries provide common functions.
Tools:  

1.	VS Code:- Visual studio code, also commonly referred to as VS code, is a source-code editor made by Microsoft for windows, Linux and macOS. Features include support for debugging, syntax highlighting, intelligent code completion, code refactoring and embedded Git.
2.	Anaconda:- Anaconda is a distribution of the Python and R programming languages for scientific computing, that aims to simplify package management and deployment. The distribution includes data-science package suitable for Windows, Linux and 

macOS.
3.	Jupyter:- Jupyter is a project and community whose goal is to develop open-source software, open-standards, and services for interactive computing across dozens of programming languages. 
4.	Excel:- Microsoft Excel is a spreadsheet developed by Microsoft for windows, MacOS, Android and iOS. If features calculation or computation capabilities, graphics tools, pivot tables, and a macro programming language.  




Screenshots of task accomplished







 

















 














 



















 

















 























 















 








 






 















 








